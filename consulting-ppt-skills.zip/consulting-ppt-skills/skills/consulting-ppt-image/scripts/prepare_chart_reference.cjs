#!/usr/bin/env node
'use strict';
// Reuse the installed Forge drawing modules, then rasterize a chart reference.
// This does not call Image, certify source data, or run the full report workflow.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
const escape=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function runtimeDirectory(explicit){
 const candidates=explicit?[explicit]:[process.env.CONSULTING_FORGE_DIR,path.resolve(__dirname,'../../zerox-consulting-report-forge'),path.join(process.env.CODEX_HOME||path.join(os.homedir(),'.codex'),'skills','zerox-consulting-report-forge')].filter(Boolean);
 const found=candidates.map(p=>path.resolve(p)).find(p=>fs.existsSync(path.join(p,'assets/deck-forms.js'))&&fs.existsSync(path.join(p,'package.json')));
 if(!found)throw Error('找不到 zerox-consulting-report-forge 绘图组件；用 --runtime 指向已安装目录。不会自动安装或改用其他图型。');
 return found;
}
function args(argv){
 const out={scale:2};
 for(let i=0;i<argv.length;i++){
  const arg=argv[i];if(arg==='--help'){out.help=true;continue;}
  if(!arg.startsWith('--')){if(out.input)throw Error('只接受一个输入JSON');out.input=arg;continue;}
  const key={'--out':'out','--runtime':'runtime','--scale':'scale'}[arg];
  if(!key||!argv[i+1]||argv[i+1].startsWith('--'))throw Error('未知参数或缺少值：'+arg);
  if(key!=='scale'&&out[key]!==undefined)throw Error('参数重复：'+arg);out[key]=argv[++i];
 }
 out.scale=Number(out.scale);if(!Number.isFinite(out.scale)||out.scale<1||out.scale>4)throw Error('scale 需为1至4');
 if(!out.help&&(!out.input||!out.out))throw Error('用法：node prepare_chart_reference.cjs chart.json --out 新目录 [--runtime 技能目录] [--scale 2]');
 return out;
}
function svgSize(svg){
 const root=svg.match(/<svg\b([^>]*)>/i)?.[1];if(!root)throw Error('绘图组件没有返回SVG');
 const attr=n=>root.match(new RegExp('\\b'+n+'\\s*=\\s*["\']([^"\']+)["\']','i'))?.[1];
 const box=attr('viewBox')?.trim().split(/[\s,]+/).map(Number);
 const dimension=v=>v!==undefined&&/^\d+(?:\.\d+)?(?:px)?$/.test(v)?parseFloat(v):null;
 const width=dimension(attr('width'))??box?.[2],height=dimension(attr('height'))??box?.[3];
 if(![width,height].every(v=>Number.isFinite(v)&&v>0))throw Error('SVG需有有限的正宽高或viewBox');
 return {width,height};
}
function render(input,{runtime,inputDirectory=process.cwd()}={}){
 if(!input||typeof input!=='object'||Array.isArray(input)||typeof input.form!=='string')throw Error('输入需为含 form 的JSON对象');
 runtime=runtimeDirectory(runtime);const forms=require(path.join(runtime,'assets/deck-forms.js')),entry=forms.get(input.form);
 if(entry.kind!=='svg')throw Error('此入口只制作SVG图表参考；HTML表格或整页内容需单独制作。');
 const typography=require(path.join(runtime,'assets/deck-typography.js')),themes=require(path.join(runtime,'assets/deck-themes.js'));
 const theme=input.theme_id||'mckinsey',profile=typography.get(input.typography_id),spec=input.spec||{};
 if(!spec||typeof spec!=='object'||Array.isArray(spec))throw Error('spec 须为对象');
 themes.get(theme);
 const common={...spec,theme_id:theme,typography_id:profile.id};
 for(const key of ['width','height','fontSize'])if(input[key]!==undefined)common[key]=input[key];
 let svg,diagnostics={};
 if(entry.module==='echarts-recipes'){
  const payload={recipe:entry.export,spec,theme_id:theme,typography_id:profile.id};
  for(const key of ['width','height','fontSize'])if(common[key]!==undefined)payload[key]=common[key];
  for(const key of ['annotations','annotationOptions','padding','format'])if(spec[key]!==undefined)payload[key]=spec[key];
  const result=require(path.join(runtime,'scripts/render_echarts_svg.cjs')).render(payload);svg=result.pages[0].svg;
  diagnostics={textAudit:result.report,risks:result.risks,anchors:result.anchors};
 }else if(entry.module==='exhibit-kit'){
  svg=require(path.join(runtime,'assets/exhibit-kit.js'))[entry.export]({...common,palette:themes.palette(theme)});
 }else if(entry.module==='precision'){
  const result=require(path.join(runtime,'scripts/render_precision_exhibit.cjs')).build({...common,theme,type:entry.type});svg=result.svg;diagnostics={geometryAudit:result.audit};
 }else if(entry.module==='diagram'){
  svg=require(path.join(runtime,'scripts/render_diagram.cjs')).render({...common,form:input.form});
 }else if(input.form==='svg.custom'){
  if(typeof spec.svgFile!=='string'||!spec.svgFile.trim())throw Error('svg.custom 需提供 spec.svgFile，指向已按数据绘制的SVG');
  svg=fs.readFileSync(path.resolve(inputDirectory,spec.svgFile),'utf8');
 }else throw Error('未支持的SVG入口：'+input.form);
 const size=svgSize(svg);
 return {svg,size,profile,theme,runtime,diagnostics,form:input.form};
}
function fontStyle(runtime,profile){
 const typography=require(path.join(runtime,'assets/deck-typography.js'));
 return profile.faces.map(id=>{const face=typography.faces[id],bytes=fs.readFileSync(path.join(runtime,'assets/fonts',id+'.woff2'));
  return `@font-face{font-family:'${face.family}';font-style:normal;font-weight:${face.weight};font-display:block;src:url(data:font/woff2;base64,${bytes.toString('base64')}) format('woff2')}`;}).join('\n');
}
async function rasterize(result,file,scale){
 const {width,height}=result.size;
 if(width*scale>16384||height*scale>16384)throw Error('参考图尺寸过大，请减少宽高或scale');
 const pw=require(require.resolve('playwright',{paths:[result.runtime]}));
 const browser=await pw.chromium.launch({channel:process.env.CHROME_CHANNEL||'chrome',headless:true});
 try{
  const page=await browser.newPage({viewport:{width:Math.ceil(width),height:Math.ceil(height)},deviceScaleFactor:scale});
  const external=[];await page.route('**/*',route=>{if(route.request().url().startsWith('data:'))return route.continue();external.push(route.request().url());return route.abort();});
  const family=result.profile.body;
  await page.setContent(`<!doctype html><meta charset="utf-8"><style>${fontStyle(result.runtime,result.profile)}html,body{margin:0;width:${width}px;height:${height}px;background:white;font-family:${family};font-synthesis:none}svg{display:block}</style>${result.svg}`,{waitUntil:'load'});
  await page.evaluate(async profile=>{for(const f of profile.faces){await document.fonts.load(`${f.weight} 16px "${f.family}"`,'收入增长 0123456789');}await document.fonts.ready;}, {faces:result.profile.faces.map(id=>({id,...require(path.join(result.runtime,'assets/deck-typography.js')).faces[id]}))});
  const first=page.locator('body > svg');if(await first.count()!==1)throw Error('参考页必须只有一个根SVG');
  const bounds=await first.boundingBox();if(!bounds||Math.abs(bounds.width-width)>.5||Math.abs(bounds.height-height)>.5)throw Error('实际SVG宽高与绘图尺寸不一致；不通过拉伸解决');
  if(external.length)throw Error('SVG包含未嵌入的外部资源：'+external.slice(0,3).join('、'));
  await first.screenshot({path:file,animations:'disabled'});
  return {width:Math.round(width*scale),height:Math.round(height*scale),scale,fontsEmbedded:true};
 }finally{await browser.close();}
}
function instructions(input,result){
 const data=input.sourceData??input.spec;
 return `# 图表参考交接：${input.id||input.form}\n\n状态：参考图已渲染，数据语义及实际图像仍须由制作者核验；整页Image尚未生成。\n\n- 图表形式：${result.form}\n- 逻辑画布：${result.size.width} × ${result.size.height}\n- 参考文件：chart.png；矢量底稿：chart.svg\n- 输入图角色：本页的图表内容与几何参考；另给的品牌报告页仅作风格/布局参考。\n- 来源：${input.source||'由制作者补充真实来源定位，不得把组件或参考风格当作业务证据。'}\n\n## 交给Image的内容\n\n沿用本页已确定的标题、论证、图文预算和视觉母版，将本图安排在指定区域。保持对象及系列顺序、标签、数值、单位、零点与量尺、长度/面积/累计/连线的含义。允许统一整图缩放及适配周围版面，不拉伸或改动单个数据图元，不省略缺失和预测状态。关键值直接可见。\n\n这是生成请求，模型仍可能重绘参考，不承诺像素保留。不要仅凭附图就将整页标为数值准确；生成后逐项对照以下原始数据及编码。\n\n### 实际数据或规格\n\n\`\`\`json\n${JSON.stringify(data,null,2)}\n\`\`\`\n\n### 编码与尺度\n\n${typeof input.encoding==='string'?input.encoding:JSON.stringify(input.encoding||{},null,2)}\n\n### 重点复核对象\n\n${(Array.isArray(input.checks)&&input.checks.length?input.checks:['核对全部对象、标签、数值和单位','核对共同零点、比例尺、长度/面积及连接关系','核对0、缺失、实际/预测与来源限制']).map(c=>'- '+(typeof c==='string'?c:JSON.stringify(c))).join('\n')}\n\n最终Image采用5%连续几何容忍度：误差=绝对几何偏差÷本图完整数轴跨度或满量程轨道；100%轨道上5个百分点等于5%。先对齐零点与缩放，不能按整页宽度或各条自身目标值计算。误差≤5%（含5%）按容忍度通过并忽略，不返工、不追加Image调用；>5%才列为几何待修项。数值标签、文字、单位、N、分母、点数、离散状态、对象映射、脚注和来源仍须准确，不能用容忍度放过内容或语义错误。无法可靠判断是否超限时先核对，不凭舍入通过。仅对超限或内容/语义错误局部编辑并复查保持项；仍未解决时记录问题，不静默改成程序合成或替换图型。用户本轮另有明确阈值时按本轮要求执行。\n`;
}
async function prepare(options){
 const inputFile=path.resolve(options.input),out=path.resolve(options.out);if(fs.existsSync(out))throw Error('输出目录已存在，请使用新目录，避免覆盖已核验参考图');
 const raw=fs.readFileSync(inputFile),input=JSON.parse(raw),result=render(input,{runtime:options.runtime,inputDirectory:path.dirname(inputFile)});
 fs.mkdirSync(path.dirname(out),{recursive:true});const staging=fs.mkdtempSync(path.join(path.dirname(out),'.chart-reference-'));
 try{
  const replayInput=input.form==='svg.custom'?{...input,spec:{...input.spec,svgFile:'chart.svg'}}:input;
  const inputBytes=input.form==='svg.custom'?Buffer.from(JSON.stringify(replayInput,null,2)+'\n'):raw;
  fs.writeFileSync(path.join(staging,'chart.svg'),result.svg);fs.writeFileSync(path.join(staging,'input.json'),inputBytes);
  if(input.form==='svg.custom')fs.writeFileSync(path.join(staging,'original-input.json'),raw);
  const image=await rasterize(result,path.join(staging,'chart.png'),options.scale??2);
  const files=['chart.svg','chart.png','input.json',...(input.form==='svg.custom'?['original-input.json']:[])];
  const manifest={schemaVersion:1,id:input.id||input.form,status:'reference-rendered-needs-review',form:result.form,theme_id:result.theme,typography_id:result.profile.id,runtimeVersion:JSON.parse(fs.readFileSync(path.join(result.runtime,'package.json'))).version,logicalSize:result.size,image,source:input.source||null,checks:input.checks||[],diagnostics:result.diagnostics,inputSha256:hash(inputBytes),...(input.form==='svg.custom'?{originalInputSha256:hash(raw)}:{}),files:files.map(name=>({name,sha256:hash(fs.readFileSync(path.join(staging,name)))})),verification:{sourceData:'not_reviewed',referenceImage:'not_reviewed',finalImage:'not_generated'}};
  fs.writeFileSync(path.join(staging,'handoff.json'),JSON.stringify(manifest,null,2)+'\n');fs.writeFileSync(path.join(staging,'image-chart-instructions.md'),instructions(replayInput,result));
  fs.renameSync(staging,out);return {directory:out,reference:path.join(out,'chart.png'),svg:path.join(out,'chart.svg'),handoff:path.join(out,'handoff.json'),status:manifest.status,image};
 }catch(e){fs.rmSync(staging,{recursive:true,force:true});throw e;}
}
if(require.main===module)(async()=>{const options=args(process.argv.slice(2));if(options.help){console.log('用法：node prepare_chart_reference.cjs chart.json --out 新目录 [--runtime 技能目录] [--scale 2]');return;}console.log(JSON.stringify(await prepare(options),null,2));})().catch(e=>{console.error(e.message);process.exitCode=1});
module.exports={args,runtimeDirectory,render,prepare,svgSize};
